------------------------
-- Импорт модулей Lua --
------------------------

require('plugins/Packer')
--require('plugins/plugins')
require('setting/setting')
require('setting/setting-plugins')
--require('keymaps/keymaps')
--require('keymaps/keymaps-plugins')